public class SocketConnection {
}
