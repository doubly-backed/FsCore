package com.zxg.annotations;

public interface Vehicle {
    public void createVehicle();
}
